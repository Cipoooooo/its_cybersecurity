E' possibile inizializzare un array fornendone da subito i valori

`String[] giorni2 = {"Lunedi'", "Martedi'", "Mercoledi'", "Giovedi'", "Venerdi'", "Sabato'", "Domenica'"};`

per tutte le funzioni riguardanti gli array, Java fornisce dei metodi statici, i quali ci permettono di operare in maniera diretta su questi elementi.

![[Pasted image 20241119093040.png]]

