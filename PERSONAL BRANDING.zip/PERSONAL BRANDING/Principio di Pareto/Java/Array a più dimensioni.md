Gli array in java possono anche essere a più dimensioni

Alla dichiarazione iniziale dell'array, posso definire quante dimensioni voglio che il mio array abbia.

`int[][] a = new int[3][2]`

Un esempio di definizione dell'array può essere:

`a[1][2] = 8`

![[Pasted image 20241119094059.png]]

Se si vuole conoscere l'input in cui si va in contro, è opportuno usufruire dell'ArrayList, quest'ultimo offre dei vantaggi significativi:

- Un ArrayList può conoscere e ridursi secondo le necessità
- La classe ArrayList fornisce metodi per attività comuni, come l'inserimento e la rimozione di elementi e tante altre

![[Pasted image 20241119094421.png]]

All'interno di un ArrayList è unicamente possibile contenere degli oggetti, non tipi semplici; esempio di errore:

`ArrayList<int> lista`

==SOLO OGGETTI, NON TIPI PREDEFINITI==

![[Pasted image 20241119094606.png]]

Questi sono i metodi per agire sull'ArrayList

`import java.util.ArrayList;`
`import java.util.Collections;`
`public class App {`
    `public static void main(String[] args) throws Exception {`
        `provaArrayList();`
    `}`
    `public static void provaArrayList(){`
        `int conta = 123;`
        `ArrayList<String>lista = new ArrayList<String>();`
        `for (int i = 0; i < conta; i++) {`
            `lista.add("Sono il numero " + i);`
        `}`
        `int len = lista.size();`
        `System.out.printf("Ci sono %d elementi in lista ", len);`
        `Collections.sort(lista);`
        `lista.remove(3);`
        `String elem = lista.get(8);`
        `System.out.println(elem);`
    `}`
`}`