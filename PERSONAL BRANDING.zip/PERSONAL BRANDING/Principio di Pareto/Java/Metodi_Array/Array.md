	==Un array è una variabile, definito quindi da un nome ed un tipo, con tuttavia un indice di valori al suo interno.==

`nomeTipo[] nomeArray = new nomeTipo[numeroElementi];`
`int[] arrayInteri = new int[4];`

E' possibile attribuire un valore per ogni posizione dell'indice dell'array. 

`arrayInteri[0] = 0;`
`arrayInteri[1] = 1;`
`...`

L'indice degli array inizia dallo 0.

==E' spesso necessario scorrere tutti gli elementi presenti all'interno di un array, perché ciò accada si utilizza un ciclo `for`,==

`for(int i = 0; i < arrayInteri.length(); i++){`
`System.out.println(arrayInteri[i]);`
`}`

`for(int numero:arrayInteri){`
`System.out.println(numero);`
`}`

La seconda porzione di codice è la forma compatta della porzione inizialmente presentata.

![[Pasted image 20241115114042.png]]

