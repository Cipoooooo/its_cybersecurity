`Class Esempio{`
`public static void main (String[]a){`
`int numero = leggiNumero();`
`int doppio = faiUnCalcolo(numero);`
`double radice = radiceQuadrata(numero);`
`}`
`}`

- I metodi definiscono una sequenza di istruzioni alle quali io do un nome;
- Essi sono utili a nascondere la complessità del programma dietro ad un metodo.

`leggiNumero(){`
`Scanner scanner = new Scanner(System.in);`
`int numero=scanner.nextInt();`
`return numero;`
`}`

==In questo caso, il metodo `leggiNumero()` ritorna un `int` (intero).==
Posso in oltre creare un metodo il quale RICEVE dei dati in `int`

`int faiDeiCalcolo(int numero)`

nella stampa del risultato sarà importante il passaggio dei parametri

`stampaRisultati(doppio, radice)`

- ==nella definizione della funzione, con all'interno i calcolo relativi, non è importa che il nome di quest'ultima sia identico a quello nel metodo principale;==
- ==nel momento della stampa del metodo principale, sarà tuttavia importante usufruire degli stessi nomi definiti nel metodo `main`==

Esistono oltre tutto dei metodi i quali NON RITORNANO, essi sono chiamati "metodi `void`".
Un esempio potrebbe essere un metodo di stampa del risultato, tenendo conto del fatto che quest'ultimo non effettua dei calcoli veri e propri, ==avrà il compito di stampare i calcoli fatti da altri metodi==.

Con Java è possibile fornire dei nomi identici a 2 o più metodi, ==è tuttavia importante che i parametri passati siano differenti.==

`int faiDeiCalcoli(int a, int b, int c);`
`int faiDeiCalcoli(int a, int b);`

`int faiDeiCalcoli(int a, int b, String c);`
`int faiDeiCalcoli(int a, int b);`

il metodo termina nel momento in cui viene inserita l'istruzione `return`.

![[Pasted image 20241115095707.png]]

==Una variabile o un metodo dichiarato statico, si avvia in contemporanea alla Virtual Machine.==
Per via del loro peso a livello di sistema, è buona norma dichiarare un metodo statico solo se necessario.

==Al fine di usufruire di un metodo statico bisogna dichiarare un'istanza usufruendo dell'oggetto della classe.==

`Metodo istanza = new Metodo();` ==> Sintassi per effettuare tale procedura

Per sfruttare pienamente un metodo presente all'interno di un'istanza, si applica tale sintassi:

`istanza.volumeCubo(lunghezzaLato)` ==> Prendendo per esempio l'esercizio precedente

==Se si desidera si possono dichiarare più istanze appartenenti alla stessa classe.==

`Metodo istanza = new Metodo();`
`Metodo istanzaNumeroDue = new Metodo();`
`Metodo istanzaNumeroTre = new Metodo();`

==Per quanto possibile andrebbero quindi evitati metodi e variabili statiche, in quanto essi nascono e vivono per tutta la durata vitale dell'applicazione.==

==E' in oltre possibile istanziare altre classi pubbliche presenti all'interno dello stesso package. == 

![[Pasted image 20241115111908.png]]

Attraverso l'utilizzo della parola chiave `protected` posso rendere un metodo usufruibile solamente dalle classi presenti all'interno del package.
Al fine che questa operazione venga effettuata anche per le altre classi presenti all'interno del package, è importante importare la classe stessa.

