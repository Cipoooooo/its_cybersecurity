Java permette di lavorare con i File attraverso il package Java.io

`File fileHello = new File("c:\\hello.txt");`

==Questo oggetto può essere letto oppure scritto==

Il file rimane qualcosa di esterno al nostro programma, non interno ad esso, per cui risulta utile usufruire di un'eccezione.

![[Pasted image 20241119104327.png]]

==Queste eccezioni fanno parte del core di Java, nel caso queste eccezioni non venissero gestite, sarebbe impossibile persino compilare.==

Una volta che si ha l'accesso al file, per cui quest'ultimo viene puntato, è possibile modificarlo.

`PrintWriter out = new PrintWriter(file);`

E' in oltre necessario ricordare di chiudere l'oggetto.

`out.close();`

![[Pasted image 20241119105134.png]]

In questo tipo di lettura, il ciclo prevede che lo scanner prenda in considerazione il file che è stato linkato nell'esempio, per poi leggere ogni singola parola del file, fino al termine di esso.

