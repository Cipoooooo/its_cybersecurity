La memoria di Java è suddivida in 2 parti, ==STACK== ed ==HEAP==.

Nello stack sono memorizzati i valori di tipo predefinito, quando le variabili non servono più, Java le marca per poi effettuare un processo di pulizia.

Nel Heap sono invece memorizzati gli oggetti.

==All'avvio del JDK, di conseguenza in fase di Runtime, tutte le variabili non utilizzate vanno a finire all'interno del Garbage Collector.==

